/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.whileloop;

/**
 *
 * @author HP
 */
public class WhileLoop {
    public static void main(String[] args) {
        int i = 0;
        while (i < 10) {
            System.out.println("Iteration: " + i);
            i++;
        }
    }
}