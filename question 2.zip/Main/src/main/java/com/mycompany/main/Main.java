/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

import java.util.Scanner;

/**
 *
 * @author HP
 */

class Circle {
    double radius;
    double area;
    double circumference;

    // Constructor
    Circle(double r) {
        this.radius = r;
        this.area = Math.PI * r * r;
        this.circumference = 2 * Math.PI * r;
    }

    // Method to display the results
    void display() {
        System.out.println("Area: " + area);
        System.out.println("Circumference: " + circumference);
    }
}
public class Main {

    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        System.out.print("Enter radius: ");
        double radius = scanner.nextDouble();

        // Create Circle object
        Circle circle = new Circle(radius);
        circle.display();
    }
}
